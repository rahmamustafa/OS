import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

public class MyServer {

	public static void main(String[] args) {

		
		try {
			ServerSocket ss = new ServerSocket(6666);
			System.out.println("Server  listen on port 6666 ...... ");
			// while(true){
			Socket s ;// establishes connection
			ObjectInputStream dis;
			int mat[][][] = new int[3][][];


			Object input[] = new Object[3];
			for (int i=1;i<3;i++ ){
				s = ss.accept();
				dis = new ObjectInputStream(s.getInputStream());
				input[i]=dis.readObject();
				mat[i] = (int[][]) input[i];
			}

			int res[][] = new int[2][2];
			for(int i=0;i<2;i++){
				for(int j=0;j<2;j++){
					res[i][j] = 0;
					for(int k=0;k<2;k++){
						res[i][j] += mat[1][i][k] * mat[2][k][j];
					}
				}
			}
			for(int i=0;i<2;i++) {
				for (int j = 0; j < 2; j++) {
					System.out.println("message= " + res[i][j]);
				}
			}

		   //}
			ss.close();

		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
