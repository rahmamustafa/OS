
import java.io.*;
import java.net.*;

public class MyClient {
	public static void main(String[] args) {
		try {
			
			Socket s = new Socket("localhost", 6666);

			ObjectOutputStream dout = new ObjectOutputStream(s.getOutputStream());
			int A[][]={{1,2},{3,4}};
			dout.writeObject(A);
			dout.flush();
			dout.close();
			s.close();

		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
